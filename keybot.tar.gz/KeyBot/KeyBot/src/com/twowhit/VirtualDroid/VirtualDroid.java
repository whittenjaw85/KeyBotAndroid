package com.twowhit.VirtualDroid;
import java.net.Socket;
import java.io.OutputStream;
import java.io.IOException;
import java.io.InputStreamReader;


public class VirtualDroid {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//inputstream for keyboard
		
		Socket socket = null; //for networking
		OutputStream ostream = null;
		InputStreamReader reader = null;
		try{
			System.out.println("Connecting to Local Socket 4505");
			socket = new Socket("mangerine.local", 4505);
			ostream = socket.getOutputStream();
			reader = new InputStreamReader(System.in);
		}catch(IOException e){e.printStackTrace();}
		
		byte [] data = {(byte) 20, 0, 20, 0, 20};
		int in_char = 27;
		while(true){
			//Create an alt-tab interface
			//Sleep for a bit
			try{
			System.out.println("Writing to Mouse");
			ostream.write(data);}catch(IOException e){;}
			try{Thread.sleep(5000);}catch (InterruptedException e) {e.printStackTrace();}
			/*
			System.out.println("Reading from the keyboard");
			try{
				in_char = reader.read();
			}catch(IOException e){;}*/
			if(in_char == 27)
				break;//leave the while
		}
		
		System.out.println("Closing Client");
		try{
		socket.close();
		}catch(IOException e){e.printStackTrace();}
		socket = null;
	}

}
