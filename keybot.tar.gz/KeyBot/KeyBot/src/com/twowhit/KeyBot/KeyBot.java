package com.twowhit.KeyBot;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Robot;
import java.awt.AWTException;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.io.InputStream;


public class KeyBot {

	/**
	 * @param args
	 */
	//Private vars
	private static Robot robot;
	private static ServerSocket m_ServerSocket;
	private static BroadcastThread b_worker;
	
	public KeyBot()
	{
		//Create the server socket
		System.out.println("Creating Server Socket");
		try{
			m_ServerSocket = new ServerSocket(4505);
		}catch(IOException e)
		{
			e.printStackTrace();
		}
		b_worker = new BroadcastThread();
		b_worker.run();
	}
	
	public class ClientThread implements Runnable{
		
		//Private vars
		Socket m_ClientSocket = null;
		InputStream m_istream = null; //from client
		boolean exit = false;
		
		public ClientThread(Socket sock){
			m_ClientSocket = sock;
			//Create the input stream
			try{
				m_ClientSocket.setSoTimeout(60000); //1 min
				m_istream = sock.getInputStream();
			}catch(IOException e){e.printStackTrace();}
			
			try{
				robot = new Robot();
			}catch(AWTException e){e.printStackTrace();}
		}
		
		public void run()
		{
			int fail = -1;
			byte [] data= {0,0,0,0,0};
			while(!this.exit)
			{
				//Listen for input, timeout is 10 minutes
				try{
					fail = m_istream.read(data);//read two bytes
					
					if(fail != -1)
					{
						System.out.println("Reading Data from Client");
						int act = (int) data[0];
						int key1 = (int) ( (data[1]<<8)|(data[2]) );
						int key2 = (int) ( (data[3]<<8)|(data[4]) );
						System.out.println("Act:" + act + ",Key1;"+key1+",Key2:"+key2);
						switch(act){
						case 10: //keyboard + keystroke
							robot.keyPress(key1);
							if(key2 != -1)
							{
								robot.keyPress(key2);
								robot.keyRelease(key2);
							}
							robot.keyRelease(key1);
						break;
							
						case 20: //mouse + direction and magnitude
							Point mpt = MouseInfo.getPointerInfo().getLocation();
							robot.mouseMove(mpt.x+key1, mpt.y+key2);
							//robot.mouseMove(key1, key2);
						break;
						
						default:
							//nop
						}
					}
				}catch(IOException e)
				{
					//e.printStackTrace();
					this.exit = true; 
				}
			}//end while
			
			System.out.println("Killing Client Thread");
			b_worker.SetDisconnected();
			try{
				m_ClientSocket.close();
			}catch(IOException e){e.printStackTrace();}
			
		}
	}
	
	public class BroadcastThread implements Runnable{
		private boolean connected = false;
		private boolean exit = false;
		//Execute thread
		
		public BroadcastThread()
		{		
			//Initialize serversocket timeout
			try{
				m_ServerSocket.setSoTimeout(15000);//30 seconds
			}catch(SocketException e)
			{
				e.printStackTrace();
			}
			
		}

		//Allows server to reset whenever a clientsocket gives up ghosts
		public void SetDisconnected()
		{
			this.connected = false;
		}
		
		public void run(){
			while(!this.exit)
			{
				if(!this.connected)
				{
					//Broadcast address ID
					
					//Listen for new requests
					try{
						System.out.println("Listening for a new Client");
						Socket sock = m_ServerSocket.accept();
						//If I get a connection, create a new socket
						ClientThread ct = new ClientThread(sock);
						this.connected = true; //mark for future pausing
						System.out.println("Connected to New Client");
						ct.run();
					}catch(IOException e)
					{
						System.out.println("Timeout listening for new client");
						//e.printStackTrace();
					}
				}
				else{
					//Timeout
					try{Thread.sleep(3000);}catch (InterruptedException e) {e.printStackTrace();}
				}
			}//end Run.while
			
			System.out.println("Closing Server Socket");
			try{m_ServerSocket.close();}catch(IOException e){;}
		}//end run
	}//end class BroadcastThread

	public static void main(String[] args) {
		KeyBot bot = new KeyBot();
	}//end main function
	
}//end class KeyBot


