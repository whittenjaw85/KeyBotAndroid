/** Automatically generated file. DO NOT MODIFY */
package com.twowhit.keybotandroid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}