package com.twowhit.keybotandroid;

import android.os.Message;
import android.util.Log;

import com.philippheckel.service.AbstractService;

import java.net.Socket;
import java.net.UnknownHostException;
import java.io.IOException;
import java.io.OutputStream;

public class KeyBotService extends AbstractService{
	public static final int MSG_SEND_DATA = 0;
	public static final int MSG_CLOSE_CONNECTION = 1;
	
	Socket sock = null;
	OutputStream ostream = null;
	
	@Override
	public void onStartService()
	{
		//Create me a socket
		try{
			sock = new Socket("192.168.0.124", 4505);
			ostream = sock.getOutputStream();
		}catch(UnknownHostException e){
			Log.v("Message", "No known host goes by that ip");
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	@Override
	public void onStopService(){
		try{
			ostream.close();
			sock.close();
		}catch(IOException e)
		{
			Log.e("Error", "Trouble closing socket");
		}
	}
	
	@Override
	public void onReceiveMessage(Message msg){
		byte [] data = (byte[]) msg.obj;
		try{
			ostream.write(data);
		}catch(IOException e){
			e.printStackTrace();
		}
		
		msg.recycle();
	}
}
