package com.twowhit.keybotandroid;

import com.philippheckel.service.ServiceManager;
import com.twowhit.keybotandroid.util.SystemUiHider;

import android.annotation.TargetApi;
import android.app.Activity;
import android.graphics.Matrix;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.util.FloatMath;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Toast;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 * 
 * @see SystemUiHider
 */
public class KeyBot extends Activity {
	/**
	 * Whether or not the system UI should be auto-hidden after
	 * {@link #AUTO_HIDE_DELAY_MILLIS} milliseconds.
	 */
	private static final boolean AUTO_HIDE = true;

	/**
	 * If {@link #AUTO_HIDE} is set, the number of milliseconds to wait after
	 * user interaction before hiding the system UI.
	 */
	private static final int AUTO_HIDE_DELAY_MILLIS = 3000;

	/**
	 * If set, will toggle the system UI visibility upon interaction. Otherwise,
	 * will show the system UI visibility upon interaction.
	 */
	private static final boolean TOGGLE_ON_CLICK = true;

	/**
	 * The flags to pass to {@link SystemUiHider#getInstance}.
	 */
	private static final int HIDER_FLAGS = SystemUiHider.FLAG_HIDE_NAVIGATION;

	/**
	 * The instance of the {@link SystemUiHider} for this activity.
	 */
	private SystemUiHider mSystemUiHider;

	
	//Some variables for good things
	Matrix matrix = new Matrix();
	Matrix eventMatrix = new Matrix();
	private ServiceManager service;
	
	final static int NONE = 0;
	final static int DRAG = 1;
	final static int ZOOM = 2;
	int touchState = NONE;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_key_bot);

		final View controlsView = findViewById(R.id.fullscreen_content_controls);
		final View contentView = findViewById(R.id.fullscreen_content);

		// Set up an instance of SystemUiHider to control the system UI for
		// this activity.
		mSystemUiHider = SystemUiHider.getInstance(this, contentView,
				HIDER_FLAGS);
		mSystemUiHider.setup();
		mSystemUiHider
				.setOnVisibilityChangeListener(new SystemUiHider.OnVisibilityChangeListener() {
					// Cached values.
					int mControlsHeight;
					int mShortAnimTime;

					@Override
					@TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
					public void onVisibilityChange(boolean visible) {
						if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
							// If the ViewPropertyAnimator API is available
							// (Honeycomb MR2 and later), use it to animate the
							// in-layout UI controls at the bottom of the
							// screen.
							if (mControlsHeight == 0) {
								mControlsHeight = controlsView.getHeight();
							}
							if (mShortAnimTime == 0) {
								mShortAnimTime = getResources().getInteger(
										android.R.integer.config_shortAnimTime);
							}
							controlsView
									.animate()
									.translationY(visible ? 0 : mControlsHeight)
									.setDuration(mShortAnimTime);
						} else {
							// If the ViewPropertyAnimator APIs aren't
							// available, simply show or hide the in-layout UI
							// controls.
							controlsView.setVisibility(visible ? View.VISIBLE
									: View.GONE);
						}

						if (visible && AUTO_HIDE) {
							// Schedule a hide().
							delayedHide(AUTO_HIDE_DELAY_MILLIS);
						}
					}
				});

		
		
		// Set up the user interaction to manually show or hide the system UI.
		contentView.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (TOGGLE_ON_CLICK) {
					mSystemUiHider.toggle();
				} else {
					mSystemUiHider.show();
				}
			}
		});

		// Upon interacting with UI controls, delay any scheduled hide()
		// operations to prevent the jarring behavior of controls going away
		// while interacting with the UI.
		findViewById(R.id.connectbutton).setOnTouchListener(
				mDelayHideTouchListener);
		
		//Configure all the buttons to have a clicklistener
		int [] btn_ids={
				R.id.prevbutton,
				R.id.nextbutton,
				R.id.connectbutton,
				R.id.stepnextbutton,
				R.id.stepprevbutton,
				R.id.closebutton,
				R.id.maxbutton
		};
		for(int i=0;i<btn_ids.length;i++)
		{
			View btn = findViewById(btn_ids[i]);
			btn.setOnClickListener(MyClick);
		}
		
		Log.v("Message", "Creating touch listener");
		//Set touchlistener for the SurfaceView
		View view = (View) findViewById(R.id.surfaceView1);
		view.setOnTouchListener(MyTouch);
		
		//Create networker 'thread'
		//Toast.makeText(KeyBot.this, "Creating Socket", Toast.LENGTH_SHORT).show();
		this.service = new ServiceManager(this, KeyBotService.class, new Handler(){
			@Override
			public void handleMessage(Message msg){
				//Receive message from service
				switch(msg.what){
				default:
					super.handleMessage(msg);
				}//endswitch
			}//end handlemessage
		});
		
		this.service.start();
		
	}// end OnCreate
	
	static byte [] data = {0,0,0,0,0};
	// Create an anonymous implementation of OnClickListener
	private OnClickListener MyClick = new OnClickListener() {
		
	    public void onClick(View v) {
	    	switch(v.getId()){
	    	case R.id.prevbutton:
	    		data[0] = (byte) 10;
	    		data[1] = 0;
	    		data[2] = 0x01;
	    		data[3] = 0;
	    		data[4] = -1;
	    	break;
	    	case R.id.nextbutton:
	    		data[0] = (byte) 10;
	    		data[1] = 0;
	    		data[2] = -1;
	    		data[3] = 0;
	    		data[4] = -1;
	    	break;
	    	case R.id.stepnextbutton:
	    		data[0] = (byte) 10;
	    		data[1] = 0;
	    		data[2] = 0x27;
	    		data[3] = 0;
	    		data[4] = -1;
	    	break;
	    	case R.id.stepprevbutton:
	    		data[0] = (byte) 10;
	    		data[1] = 0;
	    		data[2] = 0x25;
	    		data[3] = 0;
	    		data[4] = -1;
	    	break;
	    	case R.id.closebutton:
	    		data[0] = (byte) 10;
	    		data[1] = 0;
	    		data[2] = 0x12;
	    		data[3] = 0;
	    		data[4] = 0x73;
	    	break;
	    	case R.id.maxbutton:
	    		data[0] = (byte) 10;
	    		data[1] = 0;
	    		data[2] = 0x7A;
	    		data[3] = 0;
	    		data[4] = -1;
	    	break;
	    	case R.id.connectbutton:
	    		Toast.makeText(KeyBot.this, "hi", Toast.LENGTH_SHORT).show();
	    	break;
	    	default:
	    			;
	    	
	    	}//End switchcase
	 
	    	try {
				KeyBot.this.service.send(Message.obtain(null, KeyBotService.MSG_SEND_DATA, data));
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }//end function
	};//end declaration

	//Variables for touchlistener
	final static float MIN_DIST = 50;
	static float eventDistance = 0;
	static float centerX = 0, centerY = 0;
	
	private OnTouchListener MyTouch = new OnTouchListener() {
		public boolean onTouch(View v, MotionEvent evt){
			//SurfaceView view = (SurfaceView) v;
			
			switch(evt.getAction() & MotionEvent.ACTION_MASK){
			case MotionEvent.ACTION_DOWN:
				touchState = DRAG;
				centerX = evt.getX();
				centerY = evt.getY();
				eventMatrix.set(matrix);
				break;
			case MotionEvent.ACTION_POINTER_DOWN: //second finger down
				eventDistance = calcDistance(evt);
				calcMidpoint(centerX, centerY, evt);
				if(eventDistance > MIN_DIST)
				{
					eventMatrix.set(matrix);
					touchState = ZOOM;
				}
				break;
			case MotionEvent.ACTION_MOVE:
				if(touchState == DRAG)
				{//single finger drags
					int distX = (int)(evt.getX(0) - centerX);
					int distY = (int)(evt.getY(0) - centerY);
					
					matrix.set(eventMatrix);
					matrix.setTranslate(distX, distY);
					//Send mouse event
					data[0] = (byte) 20;
					data[1] = 0;
					data[2] = (byte) distX;
					data[3] = 0;
					data[4] = (byte) distY;
					//new SendData().execute(data);
					
				}else if(touchState == ZOOM)
				{
					//mutlifinger drags
					float dist = calcDistance(evt);
					if(dist > MIN_DIST)
					{
						matrix.set(eventMatrix);
						float scale = dist/eventDistance;
						matrix.postScale(scale,  scale, centerX, centerY);
					}
				}
				break;
			case MotionEvent.ACTION_UP:
			case MotionEvent.ACTION_POINTER_UP:
				touchState = NONE;
				break;
			}
			Log.v("Nothing Important", "The touchState is:" + touchState);
			return true;
		}
	};
	
	private float calcDistance(MotionEvent evt)
	{
		float x = evt.getX(0) - evt.getX(1);
		float y= evt.getY(0) - evt.getY(1);
		return FloatMath.sqrt(x*x + y*y);
	}
	
	private void calcMidpoint(float centerX, float centerY, MotionEvent evt)
	{
		centerX = (evt.getX(0) + evt.getX(1))/2;
		centerY = (evt.getY(0) + evt.getY(1))/2;
	}
	
	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);

		// Trigger the initial hide() shortly after the activity has been
		// created, to briefly hint to the user that UI controls
		// are available.
		delayedHide(100);
	}

	/**
	 * Touch listener to use for in-layout UI controls to delay hiding the
	 * system UI. This is to prevent the jarring behavior of controls going away
	 * while interacting with activity UI.
	 */
	View.OnTouchListener mDelayHideTouchListener = new View.OnTouchListener() {
		@Override
		public boolean onTouch(View view, MotionEvent motionEvent) {
			if (AUTO_HIDE) {
				delayedHide(AUTO_HIDE_DELAY_MILLIS);
			}
			return false;
		}
	};
	
	

	Handler mHideHandler = new Handler();
	Runnable mHideRunnable = new Runnable() {
		@Override
		public void run() {
			mSystemUiHider.hide();
		}
	};

	/**
	 * Schedules a call to hide() in [delay] milliseconds, canceling any
	 * previously scheduled calls.
	 */
	private void delayedHide(int delayMillis) {
		mHideHandler.removeCallbacks(mHideRunnable);
		mHideHandler.postDelayed(mHideRunnable, delayMillis);
	}

	@Override
	protected void onDestroy(){
		super.onDestroy();
		if(this.service.isRunning())
		this.service.stop();
	}
	
	@Override 
	protected void onPause(){
		super.onPause();
		if(this.service.isRunning())
			this.service.stop();
	}
	
	@Override
	protected void onResume(){
		super.onResume();
		if(!this.service.isRunning())
			this.service.start();
	}
}
